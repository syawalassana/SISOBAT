Template.home.events({
	'submit form':function(e){
		e.preventDefault();//not refresh page
		var nomor=e.target.nomor.value;
		var title=e.target.title.value;
		var pengarang=e.target.pengarang.value;
		var description=e.target.description.value;
		//alert('Title='+title+','+'description='+description);
		var obj={
			nomor:nomor,
			title:title,
			pengarang:pengarang,
			description:description
			
		}
		if(this._id){
			Meteor.call('updateData',this._id,obj);//call method from server to update
			alert('update success');
		}else{
			Meteor.call('insertData',obj);//call method from server to insert
			alert('insert success');
	}
		//alert('insert success');

	},
	'click #remove':function(e){
		crud.remove(this._id);//remove data from mongodb
		alert('delete success');
	}
});
Template.home.helpers({
	//get data from mongodb
	getData:function(){
		return crud.find();
	}
})